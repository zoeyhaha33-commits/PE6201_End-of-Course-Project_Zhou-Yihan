# EnergyInvest — Final 5-Minute Demo Script

## 0:00–0:30 — Problem
Hi, I'm Zhou Yihan, and my project is EnergyInvest, a first-pass screening tool for power-project development risk.

Energy analysts may need to review large project pipelines before deeper due diligence. My goal is not to automate investment decisions, but to reduce exhaustive first-pass screening while still capturing most historically high-risk projects.

## 0:30–1:05 — Architecture and AI choice
The core model is XGBoost, not an LLM, because this is a structured supervised-classification problem with historical labels.

The flow is simple: GIPT project records are cleaned and mapped into labels, passed through the feature pipeline, scored by XGBoost, and then converted into Low Risk, High Risk or Needs Manual Review. A language model is optional and used only for explanation.

## 1:05–1:45 — Data and evaluation design
I use the September 2026 Global Integrated Power Tracker.

High-risk labels are cancelled, cancelled-inferred after four years, shelved, and shelved-inferred after two years. Operating is the low-risk comparison group.

One important concern is that inferred labels already contain GEM heuristics, so I report confirmed and inferred recall separately.

I also use a grouped holdout by GEM location ID so that different units from the same facility do not leak across training and testing.

## 1:45–2:35 — Results and critique
On the holdout set, EnergyInvest achieved **91.58% high-risk recall**.

Confirmed-cancelled recall was **91.46%**, and cancelled-inferred recall was **91.25%**.

But recall alone is not enough. An Always-High strategy gets 100% recall while flagging 100% of projects.

EnergyInvest flags only **25.17%** of projects, corresponding to a **74.83% workload reduction**. In a 50-project pipeline, that is roughly 13 projects requiring attention instead of all 50.

The result also has clear limitations. Precision is only **35.83%**, and about **8.42%** of high-risk holdout cases are still missed. So this is appropriate for triage, not automated investment decisions.

## 2:35–4:10 — Live demo
[Show GitHub README.]

The repository documents the persona, input, output, architecture, metrics, data and evaluation design.

[Show terminal.]

The model can be retrained with:

`python -m src.train`

The training script produces the model, metrics and holdout predictions.

[Open Streamlit.]

I start the prototype with:

`streamlit run app.py`

I can upload project records and receive a risk score plus one of three outputs: Low Risk, Needs Manual Review, or High Risk.

Scores from 0.40 to 0.60 enter the abstention band, so the system exposes uncertainty instead of forcing a binary decision.

The interface also reports the flag rate, which is the business-facing measure of how much screening work remains.

## 4:10–4:45 — What changed during development
Three design choices changed after testing and feedback.

First, I added flag rate because recall alone can be gamed by flagging everything.

Second, I separated confirmed and inferred outcomes to test sensitivity to GEM's heuristic labels.

Third, I replaced the planned time-aware split with a grouped facility holdout because the actual GIPT workbook is a current snapshot and Start year is not a consistent observation timestamp.

## 4:45–5:05 — Closing
EnergyInvest shows that a relatively simple narrow-ML system can materially reduce first-pass screening without removing human judgement.

It captures about **91.6%** of historical high-risk cases while reducing screening workload by about **74.8%**.

The next step is stronger temporal validation using multiple dated GIPT releases, rather than simply adding a more complex model.

Thank you.
