# EnergyInvest — Business & Technical Trade-off Analysis

## 1. Problem and Difference Made

Energy investment analysts must screen large pipelines of prospective power projects before deciding which deserve deeper due diligence. The Global Integrated Power Tracker (GIPT) September 2026 release contains more than 183,000 facility records, making manual comparison with historical development outcomes impractical at portfolio scale.

EnergyInvest is a first-pass screening assistant that identifies projects showing patterns associated with cancellation or shelving and routes uncertain cases to manual review. The intended change is not to automate investment decisions, but to change the analyst's starting point from exhaustive screening to risk-prioritised screening.

On the holdout set, EnergyInvest captured **91.58%** of historical high-risk cases while flagging **25.17%** of projects for analyst attention. This corresponds to a **74.83% reduction in first-pass screening workload**. For a 50-project pipeline, the analyst would focus on roughly 13 projects rather than manually opening all 50.

## 2. Why Narrow Machine Learning

The core task is a bounded supervised-classification problem using structured tabular data and historical outcome labels. XGBoost is therefore more appropriate than a foundation model as the primary scorer. It can capture nonlinear interactions across project characteristics while remaining reproducible, inexpensive to run and straightforward to evaluate.

The model uses project-level fields including capacity, type, geography, technology, fuel, storage, CHP, CCS, captive-industry type and location accuracy. A foundation model is optional and restricted to translating model evidence into readable explanations. It cannot determine or override the risk label.

This architecture deliberately avoids unnecessary complexity. An agent, RAG pipeline or workflow engine would add operational overhead without solving a problem the current task requires.

## 3. Data and Label Design

Historical GIPT status is used to construct the target. High-risk outcomes are `cancelled`, `cancelled - inferred 4 y`, `shelved`, and `shelved - inferred 2 y`. `operating` forms the low-risk comparison group. `retired` is excluded because it represents a post-operation lifecycle state rather than development-stage success or failure. `announced`, `pre-construction` and `construction` are treated as unresolved and are scored after training rather than used as labelled outcomes.

A key limitation is that the two inferred statuses are partly rule-derived labels. Training on them risks reproducing GEM's own inactivity heuristics. I therefore report subgroup recall separately. Recall is **91.46% for confirmed cancelled projects** and **91.25% for cancelled-inferred projects**; shelved and shelved-inferred recall are similarly close. This reduces, but does not eliminate, concern that performance is driven mainly by inferred labels.

Leakage is another risk. Status, project names, IDs and URLs are excluded from the feature set. `Start year` is also excluded because the September 2026 workbook is a current snapshot and the field can represent actual, planned or missing dates across different project states.

## 4. Evaluation Design and Technical Trade-offs

A random row split could place different units or phases of the same facility in both training and test data, creating an artificially easy holdout. EnergyInvest therefore uses a grouped holdout based on `GEM location ID`, keeping records from the same facility together. The final resolved dataset contains **142,575 records**, with **113,991 for training** and **28,584 for holdout evaluation**.

A time-based split was initially considered. After inspecting the real data, I rejected it because GIPT is a current snapshot rather than a longitudinal panel and `Start year` is not a consistent observation timestamp. This was an important change from the initial design: using a superficially more sophisticated split would have produced a less defensible evaluation.

The model also uses an abstention band: scores from 0.40 to 0.60 become `Needs Manual Review`. These cases are counted as analyst workload rather than hidden as successful automation.

## 5. Results and Critique

High-risk recall is **91.58%**, exceeding the original 80% target. However, recall alone can be gamed: an `Always High` classifier achieves 100% recall by sending every project to the analyst. Its flag rate is therefore 100% and it provides no screening value. Conversely, `Always Low` flags nothing but misses every risky project.

EnergyInvest reaches a **25.17% flag rate**, producing the workload reduction above. This makes recall and analyst workload a paired business trade-off rather than treating one metric as sufficient.

The result is promising but not deployment-ready. **8.42% of historical high-risk holdout cases are still missed.** Precision among flagged projects is only **35.83%**, meaning many projects sent to the analyst are false positives. This is defensible for triage if the cost of additional review is lower than the cost of overlooking a risky project, but it would be unacceptable for automated capital allocation. The **11.03% abstention rate** also confirms that uncertainty remains material.

## 6. Difficulties Surpassed and Tuning

The evaluation changed materially during development. The original focus on recall was incomplete because “flag everything” achieves perfect recall. Instructor feedback led me to add flag rate and workload reduction, directly tying evaluation to analyst-hours saved.

The original label analysis also combined confirmed and inferred cancellations. I changed this to separate subgroup evaluation because inferred outcomes partially encode GEM heuristics.

Finally, the planned time-aware holdout was replaced with a grouped facility holdout after inspecting the actual workbook. These changes improved the project not by increasing model complexity, but by making the claims more defensible.

## 7. Rough Edges and Future Path

The main limitation is that the September 2026 GIPT file is a snapshot rather than a true historical panel. Future work should validate the model on multiple dated GIPT releases to test genuine forward prediction and concept drift. External variables such as permitting conditions, financing, grid constraints and country risk could also improve precision.

The next version should therefore focus less on a more complex model and more on stronger temporal validation, probability calibration, systematic threshold tuning and richer external evidence. EnergyInvest should remain a decision-support system with analyst sign-off rather than becoming an autonomous investment engine.
